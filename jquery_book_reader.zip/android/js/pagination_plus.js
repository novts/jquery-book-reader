//******************************************************

$( document ).ready(function() {
	
var PageSize=350;	

var Step=100;

var tmpDiv=$('<div style="display:none;"><div id="tmp"></div></div>');

$('.container').append(tmpDiv);

var html=$('#bb-bookblock').html();
var newHTML="";

var pos=0;

while(pos<html.length){
	
var i=pos+Step;	
var tmp="";
var tmpHeight=0;

while(tmpHeight<=PageSize){
tmp=html.substring(pos,i);	
tmpHeight=tmpDiv.html(tmp).height();
i=i+Step;
if(i>html.length){
break;	
}
}

if(tmp.lastIndexOf('<')!=-1){
 var tag=tmp.substring(tmp.lastIndexOf('<'), tmp.length); 
 
if(tag.indexOf('>')==-1){	
tmp=tmp.substring(0, tmp.lastIndexOf('<'));
}

if(tag.indexOf('</')==-1){	
tmp=tmp.substring(0, tmp.lastIndexOf('<'));	
}
	
}

pos=pos+tmp.length;

tmp='<div class="bb-item">'+tmp+'</div>';
newHTML=newHTML+tmp;

}
$('#bb-bookblock').html(newHTML);


});	
	
//*******************************************************	