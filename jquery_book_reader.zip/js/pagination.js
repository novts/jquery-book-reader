//******************************************************

$( document ).ready(function() {

var PageSize=1000;	
	
var	html=$('#bb-bookblock').html();

					
var listHTML=new Array();	 	
	 	  
  var text=html.replace(/<.*?>/g, '');    
     
    var posStart=0;	
    var posEnd=PageSize;
    var posHTML=0;
    var posReal=0;
      
    while(posEnd>text.length){
    	posEnd=posEnd-1;
    }
    
    while(posEnd<=text.length){    
    
    var i=0;
    var target="";    
    
    while((target=="")||(html.indexOf(target)==-1)||(target.length==1)||(target.indexOf("\r")!= -1)){      
    
    if(posEnd>=text.length) {
    posEnd=posEnd-i;   
           
    }else{
    posEnd=posEnd+i;   
      
    }
    
    page=text.substring(posStart,posEnd);
    var split = page.split(" ");    	  	
    target=split[split.length-1];   
    i++;
    }
  
  
  
var j = -1;
    
    
var tmpHTML;
var tmpText;
var tmppos;

while ( (j = html.indexOf(target, j+1)) != -1) { 
	
 tmpHTML=html.substring(0, j)+target; 
 tmpText=tmpHTML.replace(/<.*?>/g, ''); 

 tmppos=j;
 
 if(tmpText.length>=page.length){
 	
 	break; 	
 }

}

tmpHTML=html.substring(0, tmppos);
posReal=posReal+tmpText.lastIndexOf(target);
posStart=posReal;
posEnd=posStart+PageSize; 

if(posEnd>text.length){
	
	tmpHTML=html;
	listHTML.push(tmpHTML);
	
	break;
}

listHTML.push(tmpHTML);
posHTML=tmppos;
html=html.substring(posHTML);

} 
    
    html="";
for(var k=0;k<listHTML.length;k++) {
	listHTML[k]='<div class="bb-item">'+listHTML[k]+'</div>';
	html=html+listHTML[k];
}   
$('#bb-bookblock').html(html);

$('nav').append( "<span style='color:blue; font-size:0.8em;'><b>Pages: "+listHTML.length+"</b></span>" );
	
});	
	
//*******************************************************	